import os
import zipfile

# Crear carpeta del proyecto
os.makedirs("PapeleriaMorte/imagenes", exist_ok=True)

# Crear el archivo index.html
html_content = """<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Librería - Página Editable</title>
<style>
/* (Aquí pega todo el CSS que te pasé antes) */
</style>
</head>
<body>
<!-- (Aquí pega todo el HTML que te pasé antes) -->
</body>
</html>
"""

with open("PapeleriaMorte/index.html", "w", encoding="utf-8") as f:
    f.write(html_content)

# Crear el ZIP
with zipfile.ZipFile("PapeleriaMorte.zip", "w", zipfile.ZIP_DEFLATED) as zipf:
    for foldername, subfolders, filenames in os.walk("PapeleriaMorte"):
        for filename in filenames:
            file_path = os.path.join(foldername, filename)
            zipf.write(file_path, os.path.relpath(file_path, "PapeleriaMorte"))

print("¡ZIP creado! Archivo PapeleriaMorte.zip listo para subir a GitHub.")
